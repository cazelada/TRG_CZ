import { Controller } from '@nestjs/common';

@Controller('measures')
export class MeasuresController {}
