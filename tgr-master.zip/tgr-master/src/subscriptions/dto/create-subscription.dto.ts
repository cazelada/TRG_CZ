export class CreateSubscriptionDto {
  name: string;

  id?: string;

  createdAt?: Date;
}
